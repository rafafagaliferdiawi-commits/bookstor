<?php
/**
 * chat_send.php - Handler pengiriman pesan chat dari pelanggan ke admin
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$userId = getUserId();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $orderId = (int)($_POST['order_id'] ?? 0);
    $message = trim($_POST['message'] ?? '');

    // Pastikan pesanan milik user yang login
    $stmt = $pdo->prepare("SELECT id FROM orders WHERE id = ? AND user_id = ?");
    $stmt->execute([$orderId, $userId]);
    if ($stmt->fetch() && $message !== '') {
        $pdo->prepare("INSERT INTO chats (order_id, sender_id, sender_type, message)
                       VALUES (?, ?, 'user', ?)")
            ->execute([$orderId, $userId, $message]);
    }
}

if ($orderId > 0) {
    redirect("chat.php?order=$orderId");
}
redirect('chat.php');
