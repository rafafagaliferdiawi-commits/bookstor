<?php
/**
 * about.php - Halaman Tentang Kami
 * Menampilkan informasi tentang toko buku.
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

require_once 'includes/header.php';
?>

<div class="row">
    <div class="col-lg-8 mx-auto">
        <div class="card shadow-sm mb-4">
            <div class="card-header bg-primary text-white">
                <h4 class="mb-0"><i class="bi bi-info-circle"></i> Tentang Kami</h4>
            </div>
            <div class="card-body">
                <p class="lead">Selamat datang di Bookstore, toko buku online yang menyediakan berbagai koleksi buku berkualitas untuk pembaca di seluruh Indonesia.</p>

                <h5>Visi Kami</h5>
                <p>Menjadi toko buku online terpercaya yang memudahkan setiap orang mendapatkan buku favoritnya dengan harga terjangkau dan pelayanan prima.</p>

                <h5>Misi Kami</h5>
                <ul>
                    <li>Menyediakan koleksi buku lengkap dari berbagai kategori dan penulis.</li>
                    <li>Memberikan pengalaman belanja online yang aman, nyaman, dan cepat.</li>
                    <li>Menyokong minat baca masyarakat melalui layanan yang terjangkau.</li>
                </ul>

                <hr class="my-4">

                <h5>Kontak Kami</h5>
                <p><i class="bi bi-envelope"></i> support@bookstore.com</p>
                <p><i class="bi bi-telephone"></i> 0812-3456-7890</p>
                <p><i class="bi bi-geo-alt"></i> Jakarta, Indonesia</p>

                <a href="index.php" class="btn btn-primary mt-3"><i class="bi bi-arrow-left"></i> Kembali ke Beranda</a>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
