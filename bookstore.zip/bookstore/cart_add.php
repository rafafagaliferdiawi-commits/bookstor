<?php
/**
 * Handler tambah buku ke keranjang.
 * Pengguna wajib login sebelum menambahkan item.
 */
require_once 'config/database.php';
require_once 'includes/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    redirect('index.php');
}

// Simpan tujuan agar setelah login kembali ke proses tambah keranjang.
if (!isLoggedIn()) {
    $_SESSION['after_login'] = 'detail.php?id=' . (int)($_POST['book_id'] ?? 0);
    setFlash('message', 'Silakan login terlebih dahulu untuk menambahkan buku ke keranjang.');
    redirect('login.php');
}

$bookId = (int)($_POST['book_id'] ?? 0);
$quantity = max(1, (int)($_POST['quantity'] ?? 1));

$stmt = $pdo->prepare("SELECT id, title, price FROM books WHERE id = ?");
$stmt->execute([$bookId]);
$book = $stmt->fetch();

if (!$book) {
    setFlash('message', 'Buku tidak ditemukan.');
    redirect('index.php');
}

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

if (isset($_SESSION['cart'][$bookId])) {
    $_SESSION['cart'][$bookId]['quantity'] += $quantity;
} else {
    $_SESSION['cart'][$bookId] = [
        'book_id' => $book['id'],
        'title' => $book['title'],
        'price' => $book['price'],
        'quantity' => $quantity
    ];
}

setFlash('message', 'Buku berhasil ditambahkan ke keranjang!');
redirect('cart.php');
?>
