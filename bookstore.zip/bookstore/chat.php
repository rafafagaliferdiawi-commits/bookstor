<?php
/**
 * chat.php - Halaman chat pelanggan dengan admin
 * Menampilkan daftar pesanan pelanggan dan fitur chat
 * untuk masing-masing pesanan yang telah di-checkout.
 */

require_once 'config/database.php';
require_once 'includes/auth.php';

// Harus login untuk mengakses chat
if (!isLoggedIn()) {
    redirect('login.php');
}

$userId = getUserId();

// --- Ambil semua pesanan milik pelanggan ---
$stmt = $pdo->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
$stmt->execute([$userId]);
$orders = $stmt->fetchAll();

// --- Ambil chat pesanan yang sedang diaktifkan ---
$activeOrderId  = isset($_GET['order']) ? (int)$_GET['order'] : null;
$chats          = [];
$orderHeader    = null;

if ($activeOrderId > 0) {
    $stmt = $pdo->prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?");
    $stmt->execute([$activeOrderId, $userId]);
    $orderHeader = $stmt->fetch();

    if ($orderHeader) {
        $stmt = $pdo->prepare("SELECT c.*, u.name AS sender_name
                               FROM chats c
                               LEFT JOIN users u ON c.sender_id = u.id
                               WHERE c.order_id = ?
                               ORDER BY c.created_at ASC");
        $stmt->execute([$activeOrderId]);
        $chats = $stmt->fetchAll();
    }
}

require_once 'includes/header.php';
?>

<h1 class="mb-4"><i class="bi bi-chat-dots"></i> Chat Admin</h1>

<?php
$flash = getFlash('message');
if ($flash): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= $flash ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Daftar Pesanan -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0"><i class="bi bi-receipt"></i> Pilih Pesanan</h5>
    </div>
    <div class="card-body p-0">
        <?php if (count($orders) > 0): ?>
            <div class="list-group list-group-flush">
                <?php foreach ($orders as $o): ?>
                    <a href="chat.php?order=<?= $o['id'] ?>"
                       class="list-group-item list-group-item-action d-flex justify-content-between align-items-center <?= ($activeOrderId == $o['id']) ? 'active' : '' ?>">
                        <div>
                            <div class="fw-bold">Pesanan #<?= $o['id'] ?></div>
                            <div class="small text-muted">
                                <?= date('d M Y H:i', strtotime($o['created_at'])) ?> •
                                Status: <span class="badge bg-<?= ['pending'=>'warning','processing'=>'info','shipped'=>'primary','delivered'=>'success'][$o['status']] ?? 'secondary' ?>">
                                    <?= ucfirst($o['status']) ?></span>
                            </div>
                        </div>
                        <span class="badge bg-primary rounded-pill">Obrolan</span>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="list-group-item text-center text-muted py-4">
                Anda belum memiliki pesanan.
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Obrolan -->
<?php if ($orderHeader): ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Obrolan - Pesanan #<?= $orderHeader['id'] ?></h5>
            <a href="chat.php" class="btn btn-sm btn-outline-secondary"><i class="bi bi-arrow-left"></i> Kembali</a>
        </div>
        <div class="card-body p-3" style="max-height: 500px; overflow-y: auto;">
            <?php if ($chats): ?>
                <?php foreach ($chats as $chat): ?>
                    <div class="d-flex mb-3 <?= $chat['sender_type'] === 'admin' ? 'justify-content-end' : 'justify-content-start' ?>">
                        <div class="<?= $chat['sender_type'] === 'admin' ? 'bg-primary text-white' : 'bg-light text-dark border' ?> px-3 py-2 rounded-3 rounded-<?= $chat['sender_type'] === 'admin' ? 'end' : 'start' ?>-4" style="max-width: 75%; word-break: break-word;">
                            <div class="small text-<?= $chat['sender_type'] === 'admin' ? 'white' : 'dark' ?>-opacity-75 mb-1 d-flex justify-content-between">
                                <span><?= htmlspecialchars($chat['sender_name'] ?? ($chat['sender_type'] === 'admin' ? 'Admin' : 'Anda')) ?></span>
                                <span><?= date('d M Y H:i', strtotime($chat['created_at'])) ?></span>
                            </div>
                            <?= nl2br(htmlspecialchars($chat['message'])) ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="text-center text-muted py-4">Belum ada percakapan pada pesanan ini.</div>
            <?php endif; ?>
        </div>
        <div class="card-footer">
            <form action="chat_send.php" method="POST">
                <input type="hidden" name="order_id" value="<?= $orderHeader['id'] ?>">
                <div class="input-group">
                    <textarea name="message" class="form-control" rows="2" placeholder="Ketik pesan untuk admin..." required></textarea>
                    <button class="btn btn-primary" type="submit"><i class="bi bi-send-fill"></i></button>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>
